﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.IO;

using MySpace;
using MySpace.Synthesizer;
using MySpace.Synthesizer.PM8;
using MySpace.Synthesizer.MMLSequencer;

namespace MyMMLChecker
{
    class Program
    {
        static void WriteLine(string str)
        {
            Debug.WriteLine(str);
            Console.WriteLine(str);
        }
        static void Write(string str)
        {
            Debug.Write(str);
            Console.Write(str);
        }
        enum ExitCode{
            Ok = 0,
            Usage = -1,
            ReadFailed = -2,
            PaserError = -3,
            WriteFailed = -4,
        }
        static int Exit(ExitCode ec, bool hitAnyKey, string message)
        {
            WriteLine(message);
            if (hitAnyKey)
            {
                WriteLine("HIT ANY KEY!");
                Console.ReadKey();
            }
            return (int)ec;
        }
        static int Main(string[] args)
        {
            //Debug.Listeners.Add(new TextWriterTraceListener(Console.Out));
            bool error = false;
            bool verbose = false;
            bool hitAnyKey = false;
            bool play = false;
            float volume = -1.0f;
            string outputfile = null;
            string inputfile = null;
            char optcmd = '\0';
            uint freq = 0;
            uint bps = 0;
            foreach(var s in args)
            {
                if (s[0] == '-')
                {
                    if ((s.Length < 2) || (optcmd != '\0'))
                    {
                        error = true;
                        break;
                    }
                    switch (s[1])
                    {
                        case 'v':
                        case 'V':
                            if (verbose)
                            {
                                error = true;
                            }
                            verbose = true;
                            break;
                        case 'p':
                        case 'P':
                            if (play)
                            {
                                error = true;
                            }
                            play = true;
                            break;
                        case 'h':
                        case 'H':
                            if (hitAnyKey)
                            {
                                error = true;
                            }
                            hitAnyKey = true;
                            break;
                        case 'o':
                        case 'O':
                            if (outputfile != null)
                            {
                                error = true;
                            }
                            optcmd = 'o';
                            break;
                        case 'f':
                        case 'F':
                            if(freq != 0)
                            {
                                error = true;
                            }
                            optcmd = 'f';
                            break;
                        case 'b':
                        case 'B':
                            if (bps != 0)
                            {
                                error = true;
                            }
                            optcmd = 'b';
                            break;
                        case 'm':
                        case 'M':
                            if (volume != -1.0f)
                            {
                                error = true;
                            }
                            optcmd = 'm';
                            break;
                        default:
                            error = true;
                            break;
                    }
                }
                else
                {
                    switch (optcmd)
                    {
                        case 'o':
                            outputfile = s;
                            break;
                        case 'f':
                            {
                                int result;
                                if (int.TryParse(s, out result))
                                {
                                    if((result < 8000) || (result > 192000))
                                    {
                                        error = true;
                                    }
                                    freq = (uint)result;
                                }
                                else
                                {
                                    error = true;
                                }
                            }
                            break;
                        case 'm':
                            {
                                float result;
                                if (float.TryParse(s, out result))
                                {
                                    if ((result < 0.0f) || (result > 1.5f))
                                    {
                                        error = true;
                                    }
                                    volume = result;
                                }
                                else
                                {
                                    error = true;
                                }
                            }
                            break;
                        case 'b':
                            {
                                int result;
                                if (int.TryParse(s, out result))
                                {
                                    switch (result)
                                    {
                                        case 8:
                                        case 16:
                                        case 24:
                                        case 32:
                                            bps = (uint)(result / 8);
                                            break;
                                        default:
                                            error = true;
                                            break;
                                    }
                                }
                                else
                                {
                                    error = true;
                                }
                            }
                            break;
                        case '\0':
                            if (inputfile != null)
                            {
                                error = true;
                            }
                            inputfile = s;
                            break;
                        default:
                            error = true;
                            break;
                    }
                    optcmd = '\0';
                }
            }
            if(play && (outputfile != null)){
                error = true;
            }
            if(!play && (volume != -1.0f))
            {
                error = true;
            }
            if ((outputfile == null) && ((freq != 0) || (bps != 0)))
            {
                error = true;
            }
            if (error || (inputfile == null))
            {
                return Exit(ExitCode.Usage, hitAnyKey, "usage:\n" +
                    "> MyMMLChecker input.mml.txt [-v] [-h]\n" +
                    "> MyMMLChecker input.mml.txt [-v] [-h] -o output.wav [-f 44100] [-b 16]\n" +
                    "> MyMMLChecker input.mml.txt [-v] [-h] -p [-m 1.0]\n" +
                    "-v: verbose\n" +
                    "-h: Hit Any Key!\n" +
                    "-p: Play direct\n" +
                    "-m: master volume\n" +
                    "-o: Output to file\n" +
                    "-f: frequency\n" +
                    "-b: bps\n"
                    );
            }
            string txt;
#if !DEBUG
            try
#endif
            {
                using (var sr = new System.IO.StreamReader(inputfile, Encoding.UTF8, true))
                {
                    txt = sr.ReadToEnd();
                }
            }
#if !DEBUG
            catch (Exception e)
            {
                return Exit(ExitCode.ReadFailed, hitAnyKey, e.Message);
            }
#endif

            MyMMLSequence mml = new MyMMLSequence(txt);
            if (mml.ErrorLine != 0)
            {
                return Exit(ExitCode.PaserError, hitAnyKey, "ParseFailed " + mml.ErrorLine + ":" + mml.ErrorPosition + ":" + mml.ErrorString + " <<<");
            }
#if !DEBUG
            try
#endif
            {
                if (play)
                {
                    if (volume == -1.0f)
                    {
                        volume = 1.0f;
                    }
                    else
                    {
                        volume *= volume;
                    }
                    playMML(mml, volume, verbose);
                }
                if(outputfile != null)
                {
                    if (freq == 0)
                    {
                        freq = 44100;
                    }
                    if (bps == 0)
                    {
                        bps = 2;
                    }
                    offlineRendering(outputfile, freq, bps, mml, verbose);
                }
            }
#if !DEBUG
            catch (System.Exception e)
            {
                return Exit(ExitCode.WriteFailed, hitAnyKey, e.Message);
            }
#endif
            return Exit(ExitCode.Ok, hitAnyKey, "Ok..");
        }
        static private void setup(MyMixer Mixer, MyMMLSequencer Sequencer, MyMMLSequence Sequence, MySynthesizer [] Synthesizers, bool verbose)
        {
            if (verbose)
            {
                foreach (KeyValuePair<string, string> pair in Sequence.Property)
                {
                    WriteLine("<" + pair.Key + "> = " + pair.Value);
                }
            }
            for (int i = 0; i < Synthesizers.Length; i++)
            {
                if(Synthesizers[i] == null)
                {
                    continue;
                }
                List<object> toneSet = new List<object>();
                Dictionary<int, int> toneMap = new Dictionary<int, int>();
                for (int j = 0; j < Sequence.ToneData.Count; j++)
                {
                    object tone = Synthesizers[i].CreateToneObject(Sequence.ToneData[j]);
                    //tone = new MySpace.Synthesizer.PM8.ToneParam(); // dummy tone
                    if (tone != null)
                    {
                        if (verbose)
                        {
                            WriteLine("Load toneData[" + Sequence.ToneName[j] + "] : <0x" + toneMap.Count.ToString("X2") + ">");
                        }
                        toneMap.Add(j, toneSet.Count);
                        toneSet.Add(tone);
                    }
                    else
                    {
                        if (!verbose)
                        {
                            Write("\n");
                        }
                        WriteLine("Failed to load toneData[" + Sequence.ToneName[j] + "] :" + Sequence.ToneData[j]);
                    }
                }
                Sequencer.SetSynthesizer(i, Synthesizers[i], toneSet, toneMap, 0xffffffffU);
            }
            if (verbose)
            {
                Sequencer.AppDataEvent = (port, channel, trackNo, measureCount, tickCount, data) =>
                {
                    WriteLine(data);
                };
                Sequencer.PlayingEvent = (port, channel, trackNo, measureCount ,tickCount, step, gate, ist, sequence, sectionIndex, instructionIndex) =>
                {
                    uint timeBase = Sequencer.TimeBase * 4 * Sequence.Score[0].MeasureBeats / Sequence.Score[0].MeasureNote;
                    string str = "" +
                        trackNo.ToString("D2") + ":" + channel.ToString("D2") + " " +
                        measureCount.ToString("D3") + ":" +
                        tickCount.ToString("D3") + " " +
                        step.ToString("D3") + ":" +
                        gate.ToString("D3") + " ";
                    if ((int)ist.N == 0)
                    {
                        str += "" + ist.N;
                    }
                    else if ((int)ist.N < 128)
                    {
                        char c0 = "ccddeffggaab"[(int)ist.N % 12];
                        char c1 = " # #  # # # "[(int)ist.N % 12];
                        int oct = ((int)ist.N / 12) - 2;
                        str += "" + c0 + c1 + oct + " " + ist.V.ToString("D3");
                    }
                    else
                    {
                        str += "" + ist.N + " <0x" + (ist.V | ((int)ist.Q << 8)).ToString("X4") + ">";
                    }
                    WriteLine(str);
                };
            }
            Mixer.TickCallback = () => Sequencer.Tick();
        }
        static private void playMML(MyMMLSequence mml, float volume, bool verbose)
        {
            MyMixer mix = new MyMixer(MySpace.DirectSound.MyDirectStream.Frequency, false);
            MyMMLSequencer seq = new MyMMLSequencer(mix.TickFrequency);
            MySynthesizer[] sss = new MySynthesizer[MyMMLSequence.MaxNumPorts];
            sss[0] = new MySynthesizerPM8(mix);
            setup(mix, seq, mml, sss, verbose);
            seq.KeyShift = 0;
            seq.VolumeShift = 0.0f;
            seq.TempoShift = 0.0f;
            seq.Play(mml, 0.0f, false);
            mix.MasterVolume = volume;
            using (var mds = new MySpace.DirectSound.MyDirectStream())
            {
                mds.Play((data, numSamples) =>
                {
                    mix.Output(data, 2, numSamples);
                });
                while (seq.Playing)
                {
                    System.Threading.Thread.Sleep(16);
                    mds.Raise();
                    mix.Update();
                }
                mds.Stop();
            }
            mix.Terminate();
            foreach(MySynthesizer s in sss)
            {
                if (s != null)
                {
                    s.Terminate();
                }
            }
        }
        static private void offlineRendering(string outputfile, uint freq, uint bps, MyMMLSequence mml, bool verbose)
        {
            using (var ww = new WaveWriter(outputfile, freq, bps))
            {
                MyMixer mix = new MyMixer(freq, true);
                MyMMLSequencer seq = new MyMMLSequencer(mix.TickFrequency);
                MySynthesizer[] sss = new MySynthesizer[MyMMLSequence.MaxNumPorts];
                sss[0] = new MySynthesizerPM8(mix);
                setup(mix, seq, mml, sss, verbose);
                seq.KeyShift = 0;
                seq.VolumeShift = 0.0f;
                seq.TempoShift = 0.0f;
                seq.Play(mml, 0.0f, false);

                int sectorSize = 588;
                int count = 0;
                int second = 0;
                float[] sector = new float[sectorSize * 2];
                while (seq.Playing)
                {
                    mix.Update();
                    for (int i = 0; i < sectorSize; i++)
                    {
                        sector[i * 2 + 0] = 0.0f;
                        sector[i * 2 + 1] = 0.0f;
                    }
                    int num = mix.Output(sector, 2, sectorSize);
                    ww.Write(sector, num);
                    count += num;
                    if (count > sectorSize * 75)
                    {
                        count %= sectorSize * 75;
                        second++;
                        if (!verbose)
                        {
                            Write(".");
                        }
                    }
                }
                for (;;)
                {
                    for (int i = 0; i < sectorSize; i++)
                    {
                        sector[i * 2 + 0] = 0.0f;
                        sector[i * 2 + 1] = 0.0f;
                    }
                    int num = mix.Output(sector, 2, sectorSize);
                    if (num == 0)
                    {
                        break;
                    }
                    ww.Write(sector, num);
                    count += num;
                    if (count > sectorSize * 75)
                    {
                        count %= sectorSize * 75;
                        second++;
                        if (!verbose)
                        {
                            Write(".");
                        }
                    }
                }
                if (count != 0)
                {
                    second++;
                }
                if (!verbose)
                {
                    Write("\n");
                }
                WriteLine("output " + second + " seconds");
                ww.Close();
                mix.Terminate();
                foreach(MySynthesizer s in sss)
                {
                    if(s != null)
                    {
                        s.Terminate();
                    }
                }
            }
        }

    }
    class WaveWriter : IDisposable
    {
        private bool disposed = false;
        private FileStream fileStream;
        private BinaryWriter binaryWriter;
        private long dataPos;
        private uint bps;
        /// <summary>8bit,16bit,24bit and 32bit float</summary>
        /// <param name="Path"></param>
        /// <param name="Freq"></param>
        /// <param name="BytesPerSample"></param>
        public WaveWriter(string Path, uint Freq, uint BytesPerSample)
        {
            bps = (BytesPerSample > 4) ? 2 : ((BytesPerSample == 0) ? 2 : BytesPerSample);
            fileStream = new FileStream(Path, FileMode.Create, FileAccess.Write);
            binaryWriter = new BinaryWriter(fileStream);

            binaryWriter.Write(new byte[4] { (byte)'R', (byte)'I', (byte)'F', (byte)'F' });
            binaryWriter.Write((UInt32)(4 + 4 + 4 + 2 + 2 + 4 + 4 + 2 + 2 + 4 + 4 + 0 * 2 * 2));   // size

            binaryWriter.Write(new byte[4] { (byte)'W', (byte)'A', (byte)'V', (byte)'E' });
            binaryWriter.Write(new byte[4] { (byte)'f', (byte)'m', (byte)'t', (byte)' ' });
            binaryWriter.Write((UInt32)(16));
            if (bps < 4)
            {
                binaryWriter.Write((UInt16)(1));            // format 1:linear pcm
            }
            else
            {
                binaryWriter.Write((UInt16)(3));            // format 3:32bit float
            }
            binaryWriter.Write((UInt16)(2));                // channels

            binaryWriter.Write((UInt32)(Freq));             // samples per sec
            binaryWriter.Write((UInt32)(Freq * bps * 2));   // bytes per sec
            binaryWriter.Write((UInt16)(bps * 2));          // bytes per sample * channels
            binaryWriter.Write((UInt16)(bps * 8));          // bits per sample

            binaryWriter.Write(new byte[4] { (byte)'d', (byte)'a', (byte)'t', (byte)'a' });
            binaryWriter.Write((UInt32)(0));
            dataPos = binaryWriter.Seek(0, SeekOrigin.Current);
        }
        ~WaveWriter()
        {
            Dispose(false);
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool Disposing)
        {
            if (!disposed)
            {
                if (Disposing)
                {
                    long len = binaryWriter.Seek(0, SeekOrigin.Current);
                    binaryWriter.Seek(4, SeekOrigin.Begin);
                    binaryWriter.Write((UInt32)(len - 8));
                    binaryWriter.Seek((int)(dataPos - 4), SeekOrigin.Begin);
                    binaryWriter.Write((UInt32)(len - dataPos));
                    binaryWriter.Close();
                    binaryWriter = null;
                    fileStream.Close();
                    fileStream = null;
                }
                disposed = true;
            }
        }
        public void Close()
        {
            Dispose();
        }
        public void Write(float[] StereoSamples, int NumSamples)
        {
            for (int i = 0; i < NumSamples * 2; i++)
            {
                float v = StereoSamples[i];
                v = (v < -1.0f) ? -1.0f : (v > +1.0f ? +1.0f : v);
                switch (bps)
                {
                    case 1:
                        {
                            Byte d = (Byte)(v * ((1 << 7) - 1) + 128.0f);
                            binaryWriter.Write(d);
                        }
                        break;
                    default:
                    case 2:
                        {
                            Int16 d = (Int16)(v * ((1 << 15) - 1));
                            binaryWriter.Write(d);
                        }
                        break;
                    case 3:
                        {
                            Int32 d = (Int32)(v * ((1 << 23) - 1));
                            binaryWriter.Write((Byte)((d >> 0) & 0xffU));
                            binaryWriter.Write((Byte)((d >> 8) & 0xffU));
                            binaryWriter.Write((Byte)((d >> 16) & 0xffU));
                        }
                        break;
                    case 4:
                        binaryWriter.Write(v);
                        break;
                }
            }
        }
    }
}
